Test for the module Entity Update
---------------------------------

Content Entity  : OK
Config Entity   : OK
